package com.itheima.service;

import com.itheima.pojo.DeptLog;

public interface DeptLogService {

    void insert(DeptLog deptLog);
}
